"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  ArrowDownToLine,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Landmark,
  Wallet,
  X,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export type MentorEarningRow = {
  id: string;
  order_id: string;
  order_item_id: string;
  course_id: string;
  mentor_user_id: string;
  member_user_id: string;
  participant_name: string;
  currency: string;
  basis_amount: number | string;
  mentor_amount: number | string;
  platform_amount: number | string;
  status: string;
  created_at: string;
};

export type MentorAgreementRow = {
  id: string;
  course_id: string;
  mentor_user_id: string;
  mentor_share_percent: number | string;
  platform_percent: number | string;
  is_active: boolean;
  agreed_at: string;
};

export type MentorWithdrawalRow = {
  id: string;
  mentor_user_id: string;
  full_name_snapshot: string;
  bank_name: string;
  account_number: string;
  amount: number | string;
  currency: string;
  status: string;
  admin_note: string | null;
  requested_at: string;
  reviewed_at: string | null;
  paid_at: string | null;
};

export type MentorCourseLabel = { id: string; title: string };

type Props = {
  mentorName: string;
  earnings: MentorEarningRow[];
  agreements: MentorAgreementRow[];
  withdrawals: MentorWithdrawalRow[];
  courses: MentorCourseLabel[];
  initialError: string | null;
};

function money(value: number | string) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(Number(value) || 0);
}

function dateTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "-"
    : new Intl.DateTimeFormat("id-ID", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(date);
}

function statusLabel(status: string) {
  const labels: Record<string, string> = {
    pending: "Menunggu",
    processing: "Diproses",
    paid: "Dibayarkan",
    rejected: "Ditolak",
  };
  return labels[status] ?? status;
}

function statusClass(status: string) {
  if (status === "paid") return "bg-emerald-50 text-emerald-700";
  if (status === "rejected") return "bg-rose-50 text-rose-700";
  if (status === "processing") return "bg-sky-50 text-sky-700";
  return "bg-amber-50 text-amber-800";
}

export default function MentorEarningsDashboard({
  mentorName,
  earnings,
  agreements,
  withdrawals,
  courses,
  initialError,
}: Props) {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  const [fullName, setFullName] = useState(mentorName);
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [isWithdrawalOpen, setIsWithdrawalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [success, setSuccess] = useState("");

  const courseMap = useMemo(
    () => new Map(courses.map((course) => [course.id, course.title] as const)),
    [courses],
  );

  const activeClassCount = agreements.filter(
    (item) => item.is_active,
  ).length;

  const availableEarnings = earnings.filter(
    (item) => item.status === "available",
  );

  const earnedTotal = availableEarnings.reduce(
    (sum, item) => sum + (Number(item.mentor_amount) || 0),
    0,
  );

  const reservedTotal = withdrawals
    .filter((item) =>
      ["pending", "processing", "paid"].includes(item.status),
    )
    .reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

  const availableTotal = Math.max(0, earnedTotal - reservedTotal);

  useEffect(() => {
    if (!isWithdrawalOpen) return;

    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape" && !submitting) {
        setIsWithdrawalOpen(false);
      }
    }

    window.addEventListener("keydown", handleEscape);

    return () => window.removeEventListener("keydown", handleEscape);
  }, [isWithdrawalOpen, submitting]);

  function openWithdrawal() {
    setFormError("");
    setSuccess("");
    setIsWithdrawalOpen(true);
  }

  async function submitWithdrawal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setSubmitting(true);
    setFormError("");
    setSuccess("");

    const requestedAmount = Number(amount);

    let validationError = "";

    if (fullName.trim().length < 3) {
      validationError = "Nama pemilik rekening minimal 3 karakter.";
    } else if (bankName.trim().length < 2) {
      validationError = "Masukkan nama bank atau e-wallet.";
    } else if (!/^\d{6,30}$/.test(accountNumber)) {
      validationError =
        "Nomor rekening harus terdiri dari 6 sampai 30 digit.";
    } else if (
      !Number.isFinite(requestedAmount) ||
      requestedAmount <= 0
    ) {
      validationError =
        "Nominal penarikan harus lebih besar dari nol.";
    } else if (requestedAmount > availableTotal) {
      validationError =
        "Nominal penarikan melebihi saldo yang tersedia.";
    }

    if (validationError) {
      setFormError(validationError);
      setSubmitting(false);
      return;
    }

    try {
      const { data, error: rpcError } = await supabase.rpc(
        "request_mentor_withdrawal",
        {
          p_full_name: fullName.trim(),
          p_bank_name: bankName.trim(),
          p_account_number: accountNumber,
          p_amount: requestedAmount,
        },
      );

      if (rpcError) throw rpcError;

      if (!data) {
        throw new Error(
          "Database tidak mengembalikan ID pengajuan penarikan.",
        );
      }

      setBankName("");
      setAccountNumber("");
      setAmount("");

      setIsWithdrawalOpen(false);

      setSuccess("Pengajuan penarikan berhasil dikirim.");

      router.refresh();
    } catch (err) {
      setFormError(
        err instanceof Error
          ? err.message
          : "Pengajuan penarikan gagal dikirim.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">

      {/* TOTAL SALDO DAN TOMBOL AKSI */}

      <section className="relative overflow-hidden rounded-[26px] bg-gradient-to-br from-[#260047] via-[#321052] to-[#09483F] p-5 text-white shadow-[0_16px_38px_rgba(38,0,71,.16)] sm:p-7">

        <div className="pointer-events-none absolute -right-12 -top-20 h-56 w-56 rounded-full bg-white/[0.07] blur-2xl" />

        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-emerald-300/[0.08] blur-2xl" />

        <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">

          <div className="min-w-0">

            <div className="flex items-center gap-2 text-white/75">

              <Wallet size={16} />

              <p className="text-[10px] font-extrabold uppercase tracking-[.2em]">
                Total Saldo
              </p>

            </div>

            <p className="mt-3 break-words text-3xl font-extrabold tracking-tight sm:text-4xl">
              {money(availableTotal)}
            </p>

            <p className="mt-2 text-xs text-white/65">
              Saldo yang tersedia untuk ditarik
            </p>

          </div>

          <div className="grid grid-cols-2 gap-2 sm:flex sm:gap-3">

            <Link
              href="/mentor/kelas"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-4 text-xs font-bold text-white transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/70"
            >
              <BookOpen size={16} />

              <span>Kelas</span>

              <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px]">
                {activeClassCount}
              </span>
            </Link>

            <button
              type="button"
              onClick={openWithdrawal}
              disabled={availableTotal <= 0}
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-xs font-extrabold text-[#260047] shadow-lg shadow-black/10 transition hover:bg-[#F1EAF7] focus:outline-none focus:ring-2 focus:ring-white/70 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <ArrowDownToLine size={16} />

              <span>Penarikan</span>
            </button>

          </div>

        </div>

      </section>

      {initialError && (
        <div
          role="alert"
          className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-700"
        >
          <AlertCircle size={15} className="mt-0.5 shrink-0" />

          <span>{initialError}</span>
        </div>
      )}

      {success && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-medium text-emerald-700"
        >
          <CheckCircle2 size={15} className="shrink-0" />

          {success}
        </div>
      )}

      {/* DATA PEMBELIAN KELAS */}

      <section className="overflow-hidden rounded-[22px] border border-[#EEEAF7] bg-white shadow-[0_8px_24px_rgba(38,0,71,.04)]">

        <div className="border-b border-slate-100 px-5 py-4 sm:px-6">
          <h3 className="text-sm font-extrabold text-slate-900">
            Data Pembelian Kelas
          </h3>
        </div>

        {availableEarnings.length === 0 ? (

          <div className="px-5 py-12 text-center">

            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-2xl bg-[#F4EFF8] text-[#5A3475]">
              <BookOpen size={19} />
            </div>

            <p className="mt-3 text-xs font-semibold text-slate-600">
              Belum ada pembelian kelas.
            </p>

          </div>

        ) : (

          <>

            <div className="hidden grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_auto_auto] gap-5 bg-[#FBFAFC] px-6 py-3 text-[10px] font-bold text-slate-400 sm:grid">

              <span>Peserta</span>

              <span>Kelas</span>

              <span className="text-right">
                Nilai pembelian
              </span>

              <span className="min-w-[130px] text-right">
                Pendapatan Mentor
              </span>

            </div>

            <div className="divide-y divide-slate-100">

              {availableEarnings.slice(0, 50).map((item) => (

                <article
                  key={item.id}
                  className="grid grid-cols-1 gap-3 px-5 py-4 sm:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_auto_auto] sm:items-center sm:gap-5 sm:px-6"
                >

                  <div className="min-w-0">

                    <p className="truncate text-xs font-bold text-slate-800">
                      {item.participant_name || "Peserta"}
                    </p>

                    <p className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-400">
                      <CalendarDays size={12} />
                      {dateTime(item.created_at)}
                    </p>

                  </div>

                  <p className="truncate text-xs font-medium text-slate-600">
                    {courseMap.get(item.course_id) ?? "Kelas"}
                  </p>

                  <div className="flex items-center justify-between gap-3 sm:block sm:text-right">

                    <span className="text-[10px] text-slate-400 sm:hidden">
                      Nilai pembelian
                    </span>

                    <span className="text-xs font-semibold tabular-nums text-slate-600">
                      {money(item.basis_amount)}
                    </span>

                  </div>

                  <div className="flex items-center justify-between gap-3 sm:block sm:min-w-[130px] sm:text-right">

                    <span className="text-[10px] text-slate-400 sm:hidden">
                      Pendapatan Mentor
                    </span>

                    <span className="text-sm font-extrabold tabular-nums text-[#09483F]">
                      {money(item.mentor_amount)}
                    </span>

                  </div>

                </article>

              ))}

            </div>

          </>

        )}

      </section>

      {/* RIWAYAT PENARIKAN */}

      <section className="overflow-hidden rounded-[22px] border border-[#EEEAF7] bg-white shadow-[0_8px_24px_rgba(38,0,71,.04)]">

        <div className="border-b border-slate-100 px-5 py-4 sm:px-6">
          <h3 className="text-sm font-extrabold text-slate-900">
            Riwayat Penarikan
          </h3>
        </div>

        {withdrawals.length === 0 ? (

          <div className="px-5 py-12 text-center">

            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-2xl bg-[#F4EFF8] text-[#5A3475]">
              <Clock3 size={19} />
            </div>

            <p className="mt-3 text-xs font-semibold text-slate-600">
              Belum ada riwayat penarikan.
            </p>

          </div>

        ) : (

          <div className="divide-y divide-slate-100">

            {withdrawals.map((item) => (

              <article
                key={item.id}
                className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6"
              >

                <div className="min-w-0">

                  <p className="text-xs font-bold text-slate-800">
                    {item.bank_name}
                  </p>

                  <p className="mt-1 text-[10px] text-slate-500">
                    {item.full_name_snapshot} · {item.account_number}
                  </p>

                  <p className="mt-1 text-[10px] text-slate-400">
                    {dateTime(item.requested_at)}
                  </p>

                  {item.admin_note && (
                    <p className="mt-2 rounded-lg bg-rose-50 px-3 py-2 text-[10px] leading-5 text-rose-700">
                      Catatan Admin: {item.admin_note}
                    </p>
                  )}

                </div>

                <div className="flex items-center justify-between gap-3 sm:shrink-0 sm:justify-end">

                  <span
                    className={`rounded-full px-3 py-1.5 text-[10px] font-bold ${statusClass(item.status)}`}
                  >
                    {statusLabel(item.status)}
                  </span>

                  <strong className="text-sm tabular-nums text-[#260047]">
                    {money(item.amount)}
                  </strong>

                </div>

              </article>

            ))}

          </div>

        )}

      </section>

      {/* POPUP FORM PENARIKAN */}

      {isWithdrawalOpen && (

        <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-slate-950/55 p-4 backdrop-blur-sm">

          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="withdrawal-dialog-title"
            className="my-auto w-full max-w-[480px] overflow-hidden rounded-[24px] border border-white/70 bg-white shadow-[0_24px_80px_rgba(15,23,42,.28)]"
          >

            <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-5 sm:px-6">

              <div>

                <div className="flex items-center gap-2 text-[#09483F]">

                  <Landmark size={17} />

                  <span className="text-[10px] font-extrabold uppercase tracking-[.16em]">
                    Penarikan Saldo
                  </span>

                </div>

                <h2
                  id="withdrawal-dialog-title"
                  className="mt-2 text-lg font-extrabold tracking-tight text-[#260047]"
                >
                  Ajukan Penarikan
                </h2>

              </div>

              <button
                type="button"
                onClick={() => !submitting && setIsWithdrawalOpen(false)}
                disabled={submitting}
                aria-label="Tutup popup"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500 transition hover:bg-slate-200 hover:text-slate-800 disabled:opacity-50"
              >
                <X size={17} />
              </button>

            </div>

            <form
              onSubmit={submitWithdrawal}
              className="space-y-4 px-5 py-5 sm:px-6"
            >

              <div className="flex items-center justify-between gap-3 rounded-2xl bg-[#F5F1F8] px-4 py-3">

                <span className="text-xs font-medium text-slate-600">
                  Saldo tersedia
                </span>

                <strong className="text-sm font-extrabold tabular-nums text-[#260047]">
                  {money(availableTotal)}
                </strong>

              </div>

              <label className="block text-xs font-bold text-slate-700">

                Nama lengkap pemilik rekening

                <input
                  required
                  minLength={3}
                  maxLength={120}
                  autoComplete="name"
                  value={fullName}
                  onChange={(event) => setFullName(event.target.value)}
                  className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#6D4388] focus:ring-4 focus:ring-[#6D4388]/10"
                  placeholder="Nama sesuai rekening"
                />

              </label>

              <label className="block text-xs font-bold text-slate-700">

                Nama bank / e-wallet

                <input
                  required
                  minLength={2}
                  maxLength={80}
                  value={bankName}
                  onChange={(event) => setBankName(event.target.value)}
                  className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#6D4388] focus:ring-4 focus:ring-[#6D4388]/10"
                  placeholder="Contoh: BCA, BSI, DANA"
                />

              </label>

              <label className="block text-xs font-bold text-slate-700">

                Nomor rekening

                <input
                  required
                  type="text"
                  inputMode="numeric"
                  autoComplete="off"
                  maxLength={30}
                  value={accountNumber}
                  onChange={(event) =>
                    setAccountNumber(
                      event.target.value.replace(/\D/g, "").slice(0, 30),
                    )
                  }
                  className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#6D4388] focus:ring-4 focus:ring-[#6D4388]/10"
                  placeholder="Masukkan nomor rekening"
                />

              </label>

              <label className="block text-xs font-bold text-slate-700">

                Nominal penarikan

                <input
                  required
                  type="number"
                  inputMode="numeric"
                  min="1"
                  max={Math.floor(availableTotal)}
                  step="1"
                  value={amount}
                  onChange={(event) => setAmount(event.target.value)}
                  className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#6D4388] focus:ring-4 focus:ring-[#6D4388]/10"
                  placeholder="Masukkan nominal"
                />

              </label>

              {formError && (

                <div
                  role="alert"
                  className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-xs leading-5 text-rose-700"
                >

                  <AlertCircle size={15} className="mt-0.5 shrink-0" />

                  <span>{formError}</span>

                </div>

              )}

              <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end">

                <button
                  type="button"
                  onClick={() => setIsWithdrawalOpen(false)}
                  disabled={submitting}
                  className="inline-flex h-11 items-center justify-center rounded-xl border border-slate-200 px-5 text-xs font-bold text-slate-600 transition hover:bg-slate-50 disabled:opacity-50"
                >
                  Batal
                </button>

                <button
                  type="submit"
                  disabled={
                    submitting ||
                    availableTotal <= 0 ||
                    !fullName.trim() ||
                    !bankName.trim() ||
                    !accountNumber ||
                    !amount
                  }
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#260047] to-[#09483F] px-5 text-xs font-extrabold text-white shadow-lg shadow-[#260047]/15 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {submitting ? "Mengirim..." : "Ajukan Penarikan"}

                  {!submitting && <ArrowDownToLine size={15} />}
                </button>

              </div>

            </form>

          </section>

        </div>

      )}

    </div>
  );
}