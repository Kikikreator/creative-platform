"use client";

import { useEffect, useState } from "react";
import { AppWindow, ChevronLeft, ChevronRight, Images } from "lucide-react";

export type CaseStudySlide = {
  url: string;
  path?: string;
  alt?: string | null;
};

export type UsedAppItem = {
  name: string;
  url: string;
  path?: string;
  alt?: string | null;
};

type Props = {
  apps: UsedAppItem[];
  images: CaseStudySlide[];
  courseTitle: string;
};

export default function CourseToolsAndCaseStudies({ apps, images, courseTitle }: Props) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (images.length <= 1 || paused) return;
    const interval = window.setInterval(() => {
      setActiveIndex((current) => (current + 1) % images.length);
    }, 3800);
    return () => window.clearInterval(interval);
  }, [images.length, paused]);

  if (apps.length === 0 && images.length === 0) return null;

  const currentIndex = images.length > 0 ? activeIndex % images.length : 0;
  const activeImage = images[currentIndex];
  const showPrevious = () => setActiveIndex((current) => (current - 1 + images.length) % images.length);
  const showNext = () => setActiveIndex((current) => (current + 1) % images.length);

  return (
    <section className="mt-6 grid items-stretch gap-4 md:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)]" aria-label="Aplikasi dan contoh studi kasus">
      <article className="min-w-0 rounded-[22px] border border-[#EAE5ED] bg-white p-4 shadow-[0_8px_24px_rgba(38,0,71,.035)] sm:p-5">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#EDF4F2] text-[#09483F]">
            <AppWindow size={17} />
          </div>
          <div className="min-w-0">
            <p className="text-[8px] font-extrabold uppercase tracking-[0.15em] text-[#74627E]">TOOLS & SOFTWARE</p>
            <h2 className="mt-0.5 text-sm font-extrabold text-[#21182A]">Aplikasi yang Digunakan</h2>
          </div>
        </div>

        {apps.length > 0 ? (
          <div className="mt-4 grid grid-cols-2 gap-2.5">
            {apps.map((app, index) => (
              <div key={app.path ?? `${app.name}-${index}`} className="flex min-w-0 items-center gap-2.5 rounded-xl border border-[#F0ECF2] bg-[#FCFBFD] p-2.5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#EEEAF2] bg-white p-1.5">
                  <img src={app.url} alt={app.alt || app.name} loading="lazy" className="h-full w-full object-contain" />
                </div>
                <span className="min-w-0 break-words text-[10px] font-bold leading-4 text-[#51465D]">{app.name}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4 flex min-h-[118px] items-center justify-center rounded-xl border border-dashed border-[#DED6E3] bg-[#FCFBFD] px-4 text-center text-[10px] leading-5 text-[#948B9B]">
            Informasi aplikasi yang digunakan akan ditampilkan di sini.
          </div>
        )}
      </article>

      <article
        className="min-w-0 rounded-[22px] border border-[#EAE5ED] bg-white p-4 shadow-[0_8px_24px_rgba(38,0,71,.035)] sm:p-5"
        aria-label="Contoh studi kasus kelas"
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
        onFocus={() => setPaused(true)}
        onBlur={(event) => {
          if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setPaused(false);
        }}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#FFF4E8] text-[#C77A17]">
              <Images size={17} />
            </div>
            <div className="min-w-0">
              <p className="text-[8px] font-extrabold uppercase tracking-[0.15em] text-[#74627E]">PORTFOLIO & PRACTICE</p>
              <h2 className="mt-0.5 text-sm font-extrabold text-[#21182A]">Contoh Studi Kasus</h2>
            </div>
          </div>
          {images.length > 1 && (
            <div className="flex shrink-0 items-center gap-1.5">
              <button type="button" onClick={showPrevious} aria-label="Contoh sebelumnya" className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#EAE5ED] bg-white text-[#51465D] transition hover:bg-[#F8F6F9]">
                <ChevronLeft size={15} />
              </button>
              <button type="button" onClick={showNext} aria-label="Contoh berikutnya" className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#EAE5ED] bg-white text-[#51465D] transition hover:bg-[#F8F6F9]">
                <ChevronRight size={15} />
              </button>
            </div>
          )}
        </div>

        {activeImage ? (
          <div className="relative mt-4 overflow-hidden rounded-xl border border-[#EEEAF2] bg-[#F8F6F9]">
            <div className="flex aspect-[16/8.5] max-h-[190px] min-h-[130px] items-center justify-center bg-[#F8F6F9]">
              <img
                key={activeImage.path ?? activeImage.url}
                src={activeImage.url}
                alt={activeImage.alt || `${courseTitle} - contoh studi kasus ${currentIndex + 1}`}
                loading="lazy"
                className="h-full w-full object-contain"
              />
            </div>
            {images.length > 1 && (
              <span className="absolute bottom-2 right-2 rounded-full bg-[#21182A]/75 px-2 py-1 text-[8px] font-bold text-white">
                {currentIndex + 1} / {images.length}
              </span>
            )}
          </div>
        ) : (
          <div className="mt-4 flex min-h-[130px] items-center justify-center rounded-xl border border-dashed border-[#DED6E3] bg-[#FCFBFD] px-4 text-center text-[10px] leading-5 text-[#948B9B]">
            Contoh hasil karya kelas akan ditampilkan di sini.
          </div>
        )}

        {images.length > 1 && (
          <div className="mt-3 flex items-center justify-center gap-2" aria-label="Pilih slide contoh studi kasus">
            {images.map((image, index) => (
              <button
                key={image.path ?? image.url}
                type="button"
                onClick={() => setActiveIndex(index)}
                aria-label={`Tampilkan slide ${index + 1}`}
                aria-current={currentIndex === index ? "true" : undefined}
                className={`h-1.5 w-1.5 rounded-full transition-colors ${currentIndex === index ? "bg-[#260047] ring-2 ring-[#260047]/15" : "bg-[#D7CFDE] hover:bg-[#A99AAF]"}`}
              />
            ))}
          </div>
        )}
      </article>
    </section>
  );
}
